public class Principal{
	
	Menu menu;
	public Principal(){
		menu = new Menu();
	}
	public static void main(String args[]){
		Principal tst = new Principal();
	}
}